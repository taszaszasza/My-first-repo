package dk.easv.calculator2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label lblResult;

    private String value1 = "";
    private String savedValue1 = "";
    private String savedValue2 = "";
    private String operator = "";
    private double result;

    public void onBtnCClick(ActionEvent actionEvent) {
        value1 = "";
        operator = "";
        lblResult.setText("");
    }

    public void onBtnPlusMinusClick(ActionEvent actionEvent) {
        value1 = "-" + value1;
        lblResult.setText(value1);

    }

    public void onBtnProcentClick(ActionEvent actionEvent) {
        savedValue1 = value1;
        operator = "%";
        value1 = "";
    }

    public void onBtnDivideClick(ActionEvent actionEvent) {
        savedValue1 = value1;
        operator = "/";
        value1 = "";


    }

    public void onBtn7Click(ActionEvent actionEvent) {
        value1 = value1 + "7";
        lblResult.setText(value1);
    }

    public void onBtn8Click(ActionEvent actionEvent) {
        value1 = value1 + "8";
        lblResult.setText(value1);
    }

    public void onBtn9Click(ActionEvent actionEvent) {
        value1 = value1 + "9";
        lblResult.setText(value1);
    }

    public void onBtnMultiplyClick(ActionEvent actionEvent) {
        savedValue1 = value1;
        operator = "*";
        value1 = "";


    }

    public void onBtn4Click(ActionEvent actionEvent) {
        value1 = value1 + "4";
        lblResult.setText(value1);
    }

    public void onBtn5Click(ActionEvent actionEvent) {
        value1 = value1 + "5";
        lblResult.setText(value1);
    }

    public void onBtn6Click(ActionEvent actionEvent) {
        value1 = value1 + "6";
        lblResult.setText(value1);
    }

    public void onBtnMinusClick(ActionEvent actionEvent) {
        savedValue1 = value1;
        operator = "-";
        value1 = "";


    }

    public void onBtn1Click(ActionEvent actionEvent) {
        value1 = value1 + "1";
        lblResult.setText(value1);
    }

    public void onBtn2Click(ActionEvent actionEvent) {
        value1 = value1 + "2";
        lblResult.setText(value1);
    }

    public void onBtn3Click(ActionEvent actionEvent) {
        value1 = value1 + "3";
        lblResult.setText(value1);
    }

    public void onBtnPlusClick(ActionEvent actionEvent) {
        savedValue1 = value1;
        operator = "+";
        value1 = "";

    }

    public void onBtn0Click(ActionEvent actionEvent) {
        value1 = value1 + "0";
        lblResult.setText(value1);
    }

    public void onBtnCommaClick(ActionEvent actionEvent) {
        value1 = value1 + ".";
        lblResult.setText(value1);
    }

    public void onBtnEqualsClick(ActionEvent actionEvent) {
        savedValue2 = value1;

        switch (operator) {
            case "+":
                result = Double.parseDouble(savedValue1) + Double.parseDouble(savedValue2);
                lblResult.setText(String.valueOf(result));
                break;

                case "-":
                    result = Double.parseDouble(savedValue1) - Double.parseDouble(savedValue2);
                    lblResult.setText(String.valueOf(result));
                    break;

                    case "*":
                        result = Double.parseDouble(savedValue1) * Double.parseDouble(savedValue2);
                        lblResult.setText(String.valueOf(result));
                        break;

            case "/":
                result = Double.parseDouble(savedValue1) / Double.parseDouble(savedValue2);
                lblResult.setText(String.valueOf(result));
                break;

                case "%":
                    result = Double.parseDouble(savedValue1) % Double.parseDouble(savedValue2);
                    lblResult.setText(String.valueOf(result));
                    break;

        }

    }
}

